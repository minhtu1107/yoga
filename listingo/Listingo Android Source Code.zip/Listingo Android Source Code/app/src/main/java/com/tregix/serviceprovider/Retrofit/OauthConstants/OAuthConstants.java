package com.tregix.serviceprovider.Retrofit.OauthConstants;

/**
 * This class contains OAuth constants, used project-wide
  */
public class OAuthConstants
{
    private OAuthConstants(){}

    public static final String OUT_OF_BAND = "oob";


}