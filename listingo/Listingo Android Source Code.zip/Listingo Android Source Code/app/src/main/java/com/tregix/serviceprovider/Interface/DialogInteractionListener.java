package com.tregix.serviceprovider.Interface;

/**
 * Created by Tregix on 2/1/2018.
 */

public interface DialogInteractionListener {

    void onPositiveClick(String msg);
}
