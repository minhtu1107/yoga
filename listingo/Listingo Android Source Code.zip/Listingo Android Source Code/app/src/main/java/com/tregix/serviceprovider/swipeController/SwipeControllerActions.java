package com.tregix.serviceprovider.swipeController;

/**
 * Created by Tregix on 3/19/2018.
 */

public abstract class SwipeControllerActions {

    public void onLeftClicked(int position) {}

    public void onRightClicked(int position) {}

}