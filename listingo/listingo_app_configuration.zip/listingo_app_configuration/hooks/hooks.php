<?php

/**
 *
 * @package   ListingoApp Core
 * @author    themographics
 * @link      https://themeforest.net/user/themographics/portfolio
 * @since 1.0
 */


// add_action('plugins_loaded', 'listingoapp_configure_checkout_template');

// function listingoapp_configure_checkout_template()
// {	
// 	$my_templater = new Atemplater( array('plugin_directory' => plugin_dir_path(__FILE__), 'plugin_prefix' => 'plugin_prefix_', 'plugin_template_directory' => 'templates',));
//     $my_templater->add(array('page' => array('listingo-woo-checkout.php' => 'Checkout Android Template',),))->register();
// }




class ListingoPageTemplater {

	/**
	 * A reference to an instance of this class.
	 */
	private static $instance;

	/**
	 * The array of templates that this plugin tracks.
	 */
	protected $templates;

	/**
	 * Returns an instance of this class. 
	 */
	public static function get_instance() {

		if ( null == self::$instance ) {
			self::$instance = new ListingoPageTemplater();
		} 

		return self::$instance;

	} 

	/**
	 * Initializes the plugin by setting filters and administration functions.
	 */
	private function __construct() {

		$this->templates = array();


		// Add a filter to the attributes metabox to inject template into the cache.
		if ( version_compare( floatval( get_bloginfo( 'version' ) ), '4.7', '<' ) ) {

			// 4.6 and older
			add_filter(
				'page_attributes_dropdown_pages_args',
				array( $this, 'register_project_templates' )
			);

		} else {

			// Add a filter to the wp 4.7 version attributes metabox
			add_filter(
				'theme_page_templates', array( $this, 'add_new_template' )
			);

		}

		// Add a filter to the save post to inject out template into the page cache
		add_filter(
			'wp_insert_post_data', 
			array( $this, 'register_project_templates' ) 
		);


		// Add a filter to the template include to determine if the page has our 
		// template assigned and return it's path
		add_filter(
			'template_include', 
			array( $this, 'view_project_template') 
		);


		// Add your templates to this array.
		$this->templates = array(
			'listingo-woo-checkout.php' => 'Listingo APP Checkout',
		);
			
	} 

	/**
	 * Adds our template to the page dropdown for v4.7+
	 *
	 */
	public function add_new_template( $posts_templates ) {
		$posts_templates = array_merge( $posts_templates, $this->templates );
		return $posts_templates;
	}

	/**
	 * Adds our template to the pages cache in order to trick WordPress
	 * into thinking the template file exists where it doens't really exist.
	 */
	public function register_project_templates( $atts ) {

		// Create the key used for the themes cache
		$cache_key = 'page_templates-' . md5( get_theme_root() . '/' . get_stylesheet() );

		// Retrieve the cache list. 
		// If it doesn't exist, or it's empty prepare an array
		$templates = wp_get_theme()->get_page_templates();
		if ( empty( $templates ) ) {
			$templates = array();
		} 

		// New cache, therefore remove the old one
		wp_cache_delete( $cache_key , 'themes');

		// Now add our template to the list of templates by merging our templates
		// with the existing templates array from the cache.
		$templates = array_merge( $templates, $this->templates );

		// Add the modified cache to allow WordPress to pick it up for listing
		// available templates
		wp_cache_add( $cache_key, $templates, 'themes', 1800 );

		return $atts;

	} 

	/**
	 * Checks if the template is assigned to the page
	 */
	public function view_project_template( $template ) {
		
		// Get global post
		global $post;

		// Return template if post is empty
		if ( ! $post ) {
			return $template;
		}

		// Return default template if we don't have a custom one defined
		if ( ! isset( $this->templates[get_post_meta( 
			$post->ID, '_wp_page_template', true 
		)] ) ) {
			return $template;
		} 

		$file = plugin_dir_path( __FILE__ ). get_post_meta( 
			$post->ID, '_wp_page_template', true
		);

		// Just to be safe, we check if the file exist first
		if ( file_exists( $file ) ) {
			return $file;
		} else {
			echo $file;
		}

		// Return template
		return $template;

	}

} 
add_action( 'plugins_loaded', array( 'ListingoPageTemplater', 'get_instance' ) );


function listingo_app_hook_css() {

	if( isset($_GET['platform'])){
    ?>
        <style type="text/css">
        	#tg-footer,
        	#tg-header,
            #tg-innerbanner{
            	display: none !important;
            }
             .wc-credit-card-form.wc-payment-form{
                clear:both !important;
            }
            .wc-stripe-elements-field, .wc-stripe-iban-element-field {
                min-height: 40px;
                line-height: 40px;
            }
        </style>
    <?php
	}
}
add_action('wp_head', 'listingo_app_hook_css');
add_action('init', 'listingo_app_checkout_web_login');
function listingo_app_checkout_web_login(){
	if( isset($_GET['token'])){
		$token = base64_decode( base64_decode($_GET['token']))	;
		$user_pass = explode(':', $token);
		if( count($user_pass ) == 2){
			$info = array();
		    $info['user_login'] = $user_pass[0];
		    $info['user_password'] = $user_pass[1];
		    $info['remember'] = true;

		    $user_signon = wp_signon( $info, false );
		    if ( is_wp_error($user_signon) ){
		        echo $user->get_error_message();
		        die;
		    }
		  //  if( isset($user_signon->ID )){
		  //  	$userID = $user_signon->ID;

				// wp_set_current_user( $userID, $user_login );
				// wp_set_auth_cookie( $userID, true, false );
				// do_action( 'wp_login', $user_login );	
		  //  }else{
		  //  	var_dump($user_signon);
		  //  }
			
		}
	}

	

}

